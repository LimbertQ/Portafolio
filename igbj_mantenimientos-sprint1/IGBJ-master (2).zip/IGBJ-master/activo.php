<?php include("database.php")?>
<?php include("includes/header.php")?>


    <h1>Activo</h1>
    <link rel="stylesheet" href="styles/activo.css">
<form class="activo" method="post" >
    <div class="selectores">
        <div class="mb-3">
            <label for="Proveedor" class="form-label">Proovedor</label>
            <select name="prov" id="prov" class="form-control" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
          
        
        </div>
        
        <br>  
        <div class="mb-3">
            <label for="Clase" class="form-label">Clase</label>
            <select name="desc" id="desc" class="form-control" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
        </div>
        <br>

    
        <div class="mb-3">
            <label for="Marca" class="form-label">Marca</label>
            <select name="marc" id="marc" class="form-control1" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
          
        
        </div>
        
        <br>  
        <div class="mb-3">
            <label for="Modelo" class="form-label">Modelo</label>
            <select name="modelo" id="modelo" class="form-control" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
        </div>
        <br>

        <div class="mb-3">
            <label for="Procedencia" class="form-label">Procedecia</label>
            <select name="proc" id="proc" class="form-control" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
        </div>
        <br>
    </div>


    <div>
        <div class="mb-3">
            <label for="Año Fabricacion" class="form-label">Año Fabricacion</label>
            <select name="prov" id="prov" class="form-control" style="width:150px" required>
                <option value="opcion1"></option>
            </select>
        </div>
        <br>

        <div class="mb-3">
            <label for="Serie" class="form-label">Numero Serie</label>
            <input type="text"  id="Marca" name="marca" class="form-control" required >
        </div>
        <br>

        <div class="mb-3">
            <label for="CodigoActFijo" class="form-label">Codigo Activo Fijo</label>
            <input type="text"  id="Marca" name="marca" class="form-control" required >
        </div>
        <br>

        <div class="mb-3">
            <label for="FechaIng" class="form-label">Fecha de Ingreso</label>
            <input type="text"  id="Marca" name="marca" class="form-control" required >
        </div>

        <div class="col-lg-4 align-self-center">


            <style>
                #output { 
                position:relative; 
                left:70px; 
            } 
            </style>
            <img  id="output" top= ""width="200px" height="200px"/>
            <div style="opacity: 0;">
                Textosasasa
            </div>                    
            <div class="row">
                <input type="file" name="Imagen" accept="image/png, image/jpeg" required/>
                <div class="invalid-feedback">Necesita ingresar una imagen</div>
            </div>
        </div>


        <div class="d-flex justify-content-center flex-nowrap my-3">


            <input type="submit" value="registrar"/>
            <input type="submit" value="guardar"/>
            <input type="reset" value="cancelar"/>
        </div>
    </div>

</form>

