<link rel="stylesheet" href="styles/footer.css">
<footer>
       <div class="container_footer">
            <div class="nombref">
            <h4>INSTITUTO GASTROENTEROLOGICO BOLIVIANO JAPONES</h4>
             <p>Calle Venezuela Esq. Ismael Vasquez</p> 
             <p>Get directions</p>
             <p>Telefono: 4259198</p>
             <p>Fax: 4250699</p>
             <p><a href="#">igbjcochabamba@gmail.com</a></p>
            
           
            </div>
       </div>
        </footer>

</body>
</html>