<?php include("database.php")?>
<?php include("includes/header.php")?>
<link rel="stylesheet" href="styles">


   
<?php include("includes/footer.php")?>